{ https://manojamme27.github.io/detection-of-diabetes-using-machine-learning/ }
